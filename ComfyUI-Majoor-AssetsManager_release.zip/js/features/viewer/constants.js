export const VIEWER_ZOOM = Object.freeze({
    MIN: 0.1,
    MAX: 16,
});

