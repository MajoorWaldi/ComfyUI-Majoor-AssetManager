export const DND_MIME = "application/x-mjr-asset";
export const VIDEO_EXTS = new Set([".mp4", ".mov", ".mkv", ".webm", ".avi"]);
export const DND_GLOBAL_KEY = "__MJR_DND__";
export const DND_INSTANCE_VERSION = 1;

