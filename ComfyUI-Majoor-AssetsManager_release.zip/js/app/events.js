export const ASSET_RATING_CHANGED_EVENT = "mjr:asset-rating-changed";
export const ASSET_TAGS_CHANGED_EVENT = "mjr:asset-tags-changed";

