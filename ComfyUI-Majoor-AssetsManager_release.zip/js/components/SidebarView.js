// Compatibility shim: keep existing import path stable.
export { createSidebar, showAssetInSidebar, closeSidebar } from "./sidebar/SidebarView.js";

