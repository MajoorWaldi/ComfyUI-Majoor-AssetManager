"""Server layer for Majoor Assets Manager."""
