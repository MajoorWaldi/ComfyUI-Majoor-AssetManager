"""
Generation-info parsing (GenInfoNormalized).
"""

