"""
Index feature - file scanning and search.
"""
from .service import IndexService

__all__ = ["IndexService"]
