"""Feature modules for backend metadata extraction."""
