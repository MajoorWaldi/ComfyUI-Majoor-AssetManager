"""Adapters for external tools and storage."""
