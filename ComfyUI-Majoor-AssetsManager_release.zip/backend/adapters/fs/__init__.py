"""
Filesystem adapters (watchers, scan helpers, etc.).
"""

