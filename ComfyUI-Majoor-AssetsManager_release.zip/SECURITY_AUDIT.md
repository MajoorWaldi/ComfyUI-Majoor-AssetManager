# Security Audit Report

**Date:** 2026-01-29
**Auditor:** Claude Code
**Version:** 2.2.0

---

## Summary

| Severity | Count |
|----------|-------|
| Critical | 1 |
| High | 3 |
| Medium | 4 |
| Low | 3 |

---

## CRITICAL Issues

### CRIT-001: Unauthenticated Download Endpoint

**File:** `backend/routes/handlers/assets.py`
**Lines:** 965-1008
**Status:** [ ] Fixed

**Description:**
The `download_asset` function has NO security checks - no CSRF protection, no path validation, no authentication. It allows reading ANY file on the server.

**Current Code:**
```python
async def download_asset(request: web.Request) -> web.StreamResponse:
    filepath = request.query.get("filepath")

    if not filepath:
        return web.Response(status=400, text="Missing 'filepath' parameter")

    # NO PATH VALIDATION - ALLOWS ARBITRARY FILE READ!
    if not os.path.exists(filepath) or not os.path.isfile(filepath):
        return web.Response(status=404, text="File not found")

    # Directly serves any file...
```

**Recommended Fix:**
```python
async def download_asset(request: web.Request) -> web.StreamResponse:
    """
    Download an asset file by filepath.

    Query param: filepath (absolute path, must be within allowed roots)
    """
    from ..core import (
        _json_response,
        _normalize_path,
        _is_path_allowed,
        _is_path_allowed_custom,
        _is_within_root,
    )
    from ..core.security import _check_rate_limit

    # Rate limiting
    allowed, retry_after = _check_rate_limit(request, "download_asset", max_requests=30, window_seconds=60)
    if not allowed:
        return web.Response(status=429, text=f"Rate limit exceeded. Retry after {retry_after}s")

    filepath = request.query.get("filepath")
    if not filepath:
        return web.Response(status=400, text="Missing 'filepath' parameter")

    # Normalize and validate path
    candidate = _normalize_path(filepath)
    if not candidate:
        return web.Response(status=400, text="Invalid filepath")

    # Check path is within allowed roots
    if not (_is_path_allowed(candidate) or _is_path_allowed_custom(candidate)):
        return web.Response(status=403, text="Path not within allowed directories")

    # Strict resolution to prevent symlink escapes
    try:
        resolved = candidate.resolve(strict=True)
    except (OSError, RuntimeError, ValueError):
        return web.Response(status=404, text="File not found")

    if not resolved.is_file():
        return web.Response(status=404, text="File not found")

    # Re-validate after resolution (symlink could escape)
    if not (_is_path_allowed(resolved) or _is_path_allowed_custom(resolved)):
        return web.Response(status=403, text="Path escapes allowed directories")

    # Determine content type
    mime_type, _ = mimetypes.guess_type(str(resolved))
    if mime_type is None:
        mime_type = "application/octet-stream"

    # Sanitize filename for Content-Disposition header
    filename = resolved.name.replace('"', '').replace('\r', '').replace('\n', '')[:255]

    # Stream the file with security headers
    response = web.StreamResponse()
    response.headers["Content-Type"] = mime_type
    response.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Content-Security-Policy"] = "default-src 'none'"
    response.headers["Cache-Control"] = "no-cache"

    await response.prepare(request)

    try:
        with open(resolved, "rb") as f:
            while True:
                chunk = f.read(8192)
                if not chunk:
                    break
                await response.write(chunk)
    except Exception as e:
        get_logger(__name__).error(f"Error streaming file {resolved}: {e}")
        # Response already started, can't change status
        pass

    return response
```

**Testing:**
- [ ] Verify path traversal attempts are blocked (`../../../etc/passwd`)
- [ ] Verify symlink escapes are blocked
- [ ] Verify only files in output/input/custom roots are accessible
- [ ] Verify rate limiting works

---

## HIGH Issues

### HIGH-001: Missing Rate Limit on workflow-quick Endpoint

**File:** `backend/routes/handlers/search.py`
**Lines:** 637-704
**Status:** [ ] Fixed

**Description:**
The `/mjr/am/workflow-quick` endpoint performs SQL queries without rate limiting.

**Recommended Fix:**
Add rate limiting at the start of the function:
```python
@routes.get("/mjr/am/workflow-quick")
async def get_workflow_quick(request):
    # ADD THIS:
    allowed, retry_after = _check_rate_limit(request, "workflow_quick", max_requests=60, window_seconds=60)
    if not allowed:
        return _json_response(Result.Err("RATE_LIMITED", "Rate limit exceeded", retry_after=retry_after))

    # ... rest of function
```

---

### HIGH-002: No CSRF Protection on GET Download Endpoint

**File:** `backend/routes/handlers/scan.py`
**Lines:** 1112-1214
**Status:** [ ] Fixed

**Description:**
The GET-based download endpoint can be triggered via img tags or cross-origin requests.

**Recommended Fix:**
Option A: Add a signed token parameter that must be generated server-side:
```python
@routes.get("/mjr/am/download")
async def download_asset(request):
    # Validate download token (generated when user clicks download)
    token = request.query.get("token", "")
    if not _validate_download_token(token, request.query.get("asset_id")):
        return _json_response(Result.Err("INVALID_TOKEN", "Invalid or expired download token"))
    # ... rest of function
```

Option B: Change to POST with CSRF token (breaking change for existing clients).

---

### HIGH-003: TOCTOU Race in Path Validation

**File:** `backend/routes/core/paths.py`
**Lines:** 79-110
**Status:** [ ] Fixed

**Description:**
When checking paths that don't exist yet, `strict=False` is used, creating a window for symlink attacks.

**Recommended Fix:**
For operations on existing files, always require existence:
```python
def _is_path_allowed(candidate: Optional[Path], *, must_exist: bool = True) -> bool:
    if not candidate:
        return False

    try:
        # Always use strict=True for security-critical checks
        if must_exist:
            cand_norm = candidate.resolve(strict=True)
        else:
            # For creation paths, resolve parent strictly
            parent = candidate.parent.resolve(strict=True)
            cand_norm = parent / candidate.name
    except (OSError, RuntimeError, ValueError):
        return False

    # ... rest of validation
```

---

## MEDIUM Issues

### MED-001: Background Worker Never Terminates

**File:** `backend/routes/handlers/filesystem_new.py`
**Lines:** 98-154
**Status:** [ ] Fixed

**Description:**
The `_worker_loop` runs forever with no shutdown mechanism.

**Recommended Fix:**
```python
_WORKER_SHUTDOWN = asyncio.Event()

async def _worker_loop() -> None:
    while not _WORKER_SHUTDOWN.is_set():
        task = None
        async with _SCAN_PENDING_LOCK:
            if _SCAN_PENDING:
                _, task = _SCAN_PENDING.popitem(last=False)

        if not task:
            try:
                await asyncio.wait_for(_WORKER_SHUTDOWN.wait(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            break  # Shutdown requested

        # ... process task

def shutdown_worker():
    _WORKER_SHUTDOWN.set()
```

---

### MED-002: Debug Mode Leaks Exception Details

**File:** `backend/routes/handlers/assets.py`
**Lines:** 51-57
**Status:** [ ] Fixed

**Description:**
When `MJR_DEBUG=1`, full exception messages are returned to clients.

**Recommended Fix:**
```python
def _safe_error_message(exc: Exception, generic_message: str) -> str:
    if _DEBUG_MODE:
        # Log full details server-side, return sanitized message
        logger.debug("Debug error details: %s", exc, exc_info=True)
        # Still sanitize - remove file paths and internal details
        msg = str(exc)
        # Remove potential path information
        msg = re.sub(r'[A-Za-z]:\\[^\s]+', '[path]', msg)
        msg = re.sub(r'/[^\s]+', '[path]', msg)
        return f"{generic_message}: {msg[:200]}"
    return generic_message
```

---

### MED-003: Missing Content-Security-Policy on File Responses

**File:** `backend/routes/handlers/custom_roots.py`
**Lines:** 178-185
**Status:** [ ] Fixed

**Description:**
FileResponse doesn't include CSP header, could allow XSS if serving HTML.

**Recommended Fix:**
```python
resp = web.FileResponse(path=str(resolved_path))
resp.headers["Content-Type"] = content_type
resp.headers["Cache-Control"] = "no-cache"
resp.headers["X-Content-Type-Options"] = "nosniff"
resp.headers["Content-Security-Policy"] = "default-src 'none'"  # ADD THIS
resp.headers["X-Frame-Options"] = "DENY"  # ADD THIS
```

---

### MED-004: Large Rate Limit State Memory Usage

**File:** `backend/routes/core/security.py`
**Lines:** 52-55
**Status:** [ ] Fixed

**Description:**
Rate limit can store up to 10,000 client entries. Under attack, this uses significant memory.

**Recommended Fix:**
Reduce default and add memory-based eviction:
```python
_DEFAULT_MAX_RATE_LIMIT_CLIENTS = 1_000  # Reduced from 10,000

def _evict_oldest_clients_if_needed() -> None:
    # Evict more aggressively when near capacity
    target = int(_MAX_RATE_LIMIT_CLIENTS * 0.9)
    while len(_rate_limit_state) > target:
        try:
            _rate_limit_state.popitem(last=False)
        except KeyError:
            break
```

---

## LOW Issues

### LOW-001: Incomplete Filename Validation for Rename

**File:** `backend/routes/handlers/assets.py`
**Lines:** 737-742
**Status:** [ ] Fixed

**Description:**
Rename validation misses Windows reserved names and some edge cases.

**Recommended Fix:**
```python
_WINDOWS_RESERVED = {'CON', 'PRN', 'AUX', 'NUL', 'COM1', 'COM2', 'COM3', 'COM4',
                     'COM5', 'COM6', 'COM7', 'COM8', 'COM9', 'LPT1', 'LPT2',
                     'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9'}

def _validate_filename(name: str) -> tuple[bool, str]:
    """Validate a filename for safety."""
    if not name or not name.strip():
        return False, "Filename cannot be empty"

    name = name.strip()

    # Check for path separators
    if "/" in name or "\\" in name:
        return False, "Filename cannot contain path separators"

    # Check for null bytes
    if "\x00" in name:
        return False, "Filename cannot contain null bytes"

    # Check for control characters
    if any(ord(c) < 32 for c in name):
        return False, "Filename cannot contain control characters"

    # Check for leading/trailing dots or spaces
    if name.startswith('.') or name.startswith(' '):
        return False, "Filename cannot start with dot or space"
    if name.endswith('.') or name.endswith(' '):
        return False, "Filename cannot end with dot or space"

    # Check Windows reserved names
    name_upper = name.upper().split('.')[0]
    if name_upper in _WINDOWS_RESERVED:
        return False, f"'{name_upper}' is a reserved name"

    # Check length
    if len(name) > 255:
        return False, "Filename too long (max 255 characters)"

    return True, ""
```

---

### LOW-002: Hardcoded Constants Should Be Configurable

**File:** `backend/features/index/searcher.py`
**Lines:** 17-21
**Status:** [ ] Fixed

**Description:**
Multiple hardcoded limits that operators may want to tune.

**Recommended Fix:**
Move to `backend/config.py`:
```python
# In config.py
SEARCH_MAX_QUERY_LENGTH = int(os.environ.get("MJR_SEARCH_MAX_QUERY_LENGTH", "512"))
SEARCH_MAX_TOKENS = int(os.environ.get("MJR_SEARCH_MAX_TOKENS", "16"))
SEARCH_MAX_TOKEN_LENGTH = int(os.environ.get("MJR_SEARCH_MAX_TOKEN_LENGTH", "64"))
SEARCH_MAX_BATCH_IDS = int(os.environ.get("MJR_SEARCH_MAX_BATCH_IDS", "200"))
SEARCH_MAX_FILEPATH_LOOKUP = int(os.environ.get("MJR_SEARCH_MAX_FILEPATH_LOOKUP", "5000"))
```

---

### LOW-003: Thread Safety Pattern Could Be Cleaner

**File:** `backend/routes/core/security.py`
**Lines:** 474-488
**Status:** [ ] Fixed

**Description:**
The rate limit cleanup counter pattern works but is fragile.

**Recommended Fix:**
Use atomic counter or move cleanup to separate scheduled task:
```python
import threading

_rate_limit_cleanup_counter = threading.local()

def _get_cleanup_counter() -> int:
    if not hasattr(_rate_limit_cleanup_counter, 'value'):
        _rate_limit_cleanup_counter.value = 0
    return _rate_limit_cleanup_counter.value

def _increment_cleanup_counter() -> int:
    if not hasattr(_rate_limit_cleanup_counter, 'value'):
        _rate_limit_cleanup_counter.value = 0
    _rate_limit_cleanup_counter.value += 1
    return _rate_limit_cleanup_counter.value
```

---

## Checklist

### Before Release
- [ ] CRIT-001: Fix unauthenticated download endpoint
- [ ] HIGH-001: Add rate limiting to workflow-quick
- [ ] HIGH-002: Add CSRF protection to download
- [ ] HIGH-003: Fix TOCTOU race condition

### Next Release
- [ ] MED-001: Add worker shutdown mechanism
- [ ] MED-002: Sanitize debug error messages
- [ ] MED-003: Add CSP headers to file responses
- [ ] MED-004: Reduce rate limit memory usage

### Backlog
- [ ] LOW-001: Improve filename validation
- [ ] LOW-002: Make constants configurable
- [ ] LOW-003: Clean up thread safety pattern

---

## Testing Requirements

After fixes are applied, run the following tests:

```bash
# Run full test suite
python -m pytest tests/ -v

# Run security-specific tests
python -m pytest tests/security/ -v

# Manual tests
# 1. Try path traversal: GET /mjr/am/download?filepath=../../../etc/passwd
# 2. Try symlink escape: Create symlink in output dir pointing outside
# 3. Try rate limit bypass: Send 100 rapid requests to workflow-quick
# 4. Try CSRF: Load download URL in img tag from different origin
```

---

## Sign-off

| Role | Name | Date | Signature |
|------|------|------|-----------|
| Auditor | Claude Code | 2026-01-29 | ✓ |
| Developer | | | |
| Reviewer | | | |
