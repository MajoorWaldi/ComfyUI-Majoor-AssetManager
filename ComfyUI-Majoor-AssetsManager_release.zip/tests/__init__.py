"""
Tests for Majoor Assets Manager
"""
